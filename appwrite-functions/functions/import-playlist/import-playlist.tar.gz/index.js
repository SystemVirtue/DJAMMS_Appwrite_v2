const sdk = require('node-appwrite');
const fetch = require('node-fetch');

/**
 * Appwrite Function: import-playlist
 * Expects JSON payload: { playlistId: string, playlistUrl: string }
 * Environment variables required:
 * - APPWRITE_ENDPOINT
 * - APPWRITE_API_KEY (service key)
 * - APPWRITE_PROJECT_ID
 * - YOUTUBE_API_KEY
 */

module.exports = async function (req, res) {
  try {
    // Defensive payload parsing: `req.payload` may be undefined, already a JSON string,
    // or a JSON string that has been double-serialized. Try multiple strategies and
    // log the raw value for easier debugging in Appwrite logs.
    let payloadRaw = req.payload;
    console.log('Raw req.payload type:', typeof payloadRaw);
    console.log('Raw req.payload preview:', (payloadRaw || '').toString().slice(0, 200));

    let payload = {};
    if (!payloadRaw) {
      payload = {};
    } else if (typeof payloadRaw === 'string') {
      try {
        payload = JSON.parse(payloadRaw);
      } catch (e) {
        // Try one more time in case it's double-encoded
        try {
          payload = JSON.parse(JSON.parse(payloadRaw));
        } catch (ee) {
          console.log('Failed to parse req.payload as JSON:', e.message);
          payload = {};
        }
      }
    } else {
      payload = payloadRaw;
    }
    const playlistId = payload.playlistId;
    const playlistUrl = payload.playlistUrl;

    if (!playlistId || !playlistUrl) {
      console.log('Missing payload parameters');
      return res.json({ error: 'Missing playlistId or playlistUrl' }, 400);
    }

    // Extract playlistId param from playlistUrl if present
    const urlObj = new URL(playlistUrl);
    const listId = urlObj.searchParams.get('list') || playlistId;

    const youtubeApiKey = process.env.YOUTUBE_API_KEY;
    if (!youtubeApiKey) {
      console.log('YOUTUBE_API_KEY not configured');
      return res.json({ error: 'Missing YOUTUBE_API_KEY env var' }, 500);
    }

    const client = new sdk.Client();
    client
      .setEndpoint(process.env.APPWRITE_ENDPOINT)
      .setProject(process.env.APPWRITE_PROJECT_ID)
      .setKey(process.env.APPWRITE_API_KEY);

    const databases = new sdk.Databases(client);

    // Paginate through YouTube playlistItems
    let nextPageToken = '';
    const tracks = [];

    while (true) {
      const apiUrl = `https://www.googleapis.com/youtube/v3/playlistItems?part=snippet,contentDetails&maxResults=50&playlistId=${encodeURIComponent(listId)}&key=${youtubeApiKey}${nextPageToken ? `&pageToken=${nextPageToken}` : ''}`;
      console.log('Fetching', apiUrl);
      let r;
      try {
        r = await fetch(apiUrl);
      } catch (netErr) {
        console.log('Network error when calling YouTube API:', netErr && netErr.message);
        break;
      }

      if (!r) {
        console.log('YouTube fetch returned undefined/null');
        break;
      }

      if (!r.ok) {
        let text = '';
        try {
          text = await r.text();
        } catch (te) {
          text = `failed to read body: ${te.message}`;
        }
        console.log('YouTube API error:', r.status, text);
        break;
      }

      let json;
      try {
        json = await r.json();
      } catch (parseErr) {
        console.log('Failed to parse YouTube response as JSON:', parseErr && parseErr.message);
        break;
      }

      for (const item of json.items || []) {
        const videoId = item.contentDetails?.videoId;
        const title = item.snippet?.title || 'Unknown Title';
        const thumbnail = item.snippet?.thumbnails?.high?.url || item.snippet?.thumbnails?.default?.url || '';

        tracks.push({
          id: `yt_${videoId}`,
          video_id: videoId,
          title,
          artist: item.snippet?.videoOwnerChannelTitle || '',
          duration: 0,
          thumbnail,
          position: tracks.length,
          requested_by: 'system',
          added_at: new Date().toISOString()
        });
      }

      nextPageToken = json.nextPageToken || '';
      if (!nextPageToken) break;
    }

    // Update playlist document in Appwrite
    try {
      await databases.updateDocument(
        process.env.APPWRITE_DATABASE_ID,
        process.env.APPWRITE_PLAYLISTS_COLLECTION_ID,
        playlistId,
        {
          tracks: JSON.stringify(tracks)
        }
      );

      console.log(`Imported ${tracks.length} tracks into playlist ${playlistId}`);
      return res.json({ success: true, count: tracks.length });
    } catch (e) {
      console.log('Failed to update playlist document:', e);
      return res.json({ error: 'Failed to update playlist document', detail: e.message }, 500);
    }
  } catch (err) {
    console.log('Unexpected error in import-playlist function', err);
    return res.json({ error: 'Unexpected error', detail: err.message }, 500);
  }
};
